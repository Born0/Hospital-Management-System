﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm.Control_Ui.Doctor_Panel_Ui
{
    public partial class DoctorPanelControl : UserControl
    {
        public DoctorPanelControl()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            addDoctorControl1.Dock = DockStyle.Fill;
            addDoctorControl1.Visible = true;

            doctorListGridView.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            addDoctorControl1.Visible = false;
            doctorListGridView.Visible = true;
        }
    }
}
