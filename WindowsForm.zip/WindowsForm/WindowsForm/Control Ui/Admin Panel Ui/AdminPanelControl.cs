﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm.Control_Ui.Admin_Panel_Ui
{
    public partial class AdminPanelControl : UserControl
    {
        public AdminPanelControl()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            addAdminControl1.Dock = DockStyle.Fill;
            addAdminControl1.Visible = true;
            adminListGridView.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            addAdminControl1.Visible = false;
            adminListGridView.Visible = true;
        }
    }
}
