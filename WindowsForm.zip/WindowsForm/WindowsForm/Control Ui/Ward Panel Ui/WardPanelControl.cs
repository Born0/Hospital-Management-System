﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm.Control_Ui
{
    public partial class WardControl : UserControl
    {
        public WardControl()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            wardRoomAdd1.Visible = true;
            wardRoomAdd1.Dock = DockStyle.Fill;

            addWardControl1.Visible = false;
            wardListGridView.Visible = false;
        }

        private void loadBtn_Click(object sender, EventArgs e)
        {
            //wardListGridView.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            wardListGridView.Visible = true;

            wardRoomAdd1.Visible = false;
            addWardControl1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addWardControl1.Dock = DockStyle.Fill;
            addWardControl1.Visible = true;

            
            wardListGridView.Visible = false;
            wardRoomAdd1.Visible = false;

        }

        private void wardRoomAdd1_Load(object sender, EventArgs e)
        {

        }
    }
}
