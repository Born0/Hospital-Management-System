﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm.Control_Ui
{
    public partial class StaffPanelControl : UserControl
    {
        public StaffPanelControl()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            addStaffControl1.Dock = DockStyle.Fill;
            addStaffControl1.Visible = true;
            staffListGridView.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            staffListGridView.Visible = true;

            addStaffControl1.Visible = false;
        }

        private void staffListGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
