﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm.Entities
{
    public class Login
    {
        public string UserName { get; set; }
        public string Passsword { get; set; }
        public int  UserType  { get; set; }
    }
}
