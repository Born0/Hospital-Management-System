﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm
{
    public partial class PatientInfoControl : UserControl
    {
        public PatientInfoControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Visible = true;

            extraServicesControl1.Visible = false;
        }

        private void extraServicesBtn_Click(object sender, EventArgs e)
        {
            extraServicesControl1.Dock = DockStyle.Fill;
            extraServicesControl1.Visible = true;

            dataGridView1.Visible = false;


        }
    }
}
