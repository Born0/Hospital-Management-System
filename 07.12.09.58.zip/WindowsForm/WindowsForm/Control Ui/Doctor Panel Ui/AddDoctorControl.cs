﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsForm.Entities;
using WindowsForm.Services;

namespace WindowsForm.Control_Ui.Doctor_Panel_Ui
{
    public partial class AddDoctorControl : UserControl
    {
        public AddDoctorControl()
        {
            InitializeComponent();
        }

        private void AddDoctorControl_Load(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            Doctor edoctor = new Doctor();
            edoctor.Name = textBox2.Text;

            edoctor.Gender = comboBox1.Text;
            edoctor.Phone = textBox4.Text;
            edoctor.Address = textBox3.Text;
            edoctor.Dob = textBox8.Text;
            edoctor.Salary = Convert.ToDouble(textBox7.Text);
            edoctor.Password = textBox1.Text;
            edoctor.WId=Convert.ToInt32 (textBox5.Text);

            DoctorService doctorServices = new DoctorService();
            bool check = doctorServices.AddDoctor(edoctor);
            if (check)
            {
                MessageBox.Show("Doctor Added");
            }
            else
            {
                MessageBox.Show("Error Occured !");
            }
        }
    }
}
