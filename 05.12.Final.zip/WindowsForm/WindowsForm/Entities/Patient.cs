﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm.Entities
{
    public class Patient:Person
    {
        public string Age { get; set; }
        public string Date { get; set; }    
        public string Emergency { get; set; }
        public string DiseaseType { get; set; }
        public string Unit { get; set; }
        public string RoomType { get; set; }
        public string Seat { get; set; }
        public string Consultant { get; set; }
        public int Price { get; set; }
        public static int TotalCost { get; set; }
    }
}
