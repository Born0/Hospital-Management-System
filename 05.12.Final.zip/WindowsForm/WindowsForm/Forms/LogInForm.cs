﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsForm.Entities;
using WindowsForm.Forms;
using WindowsForm.Services;

namespace WindowsForm
{
    public partial class LogInForm : MetroFramework.Forms.MetroForm
    {
        public LogInForm()
        {
            InitializeComponent();
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = String.Empty;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
            textBox2.Text = String.Empty;
        }

        private void logInBtn_Click(object sender, EventArgs e)
        {
            LoginService ls = new LoginService();
            Login temp = new Login();
            temp.UserName = textBox1.Text;
            temp.Passsword = textBox2.Text;
            Login eLog = new Login();
            eLog=ls.LoginValidation(temp);
            if(eLog.UserType==1)
            {
                AdminForm adminForm = new AdminForm();
                adminForm.Show();
            }
            else if(eLog.UserType==2)
            {
                DoctorForm doctorForm = new DoctorForm();
                doctorForm.Show();
            }
            else if(eLog.UserType==3)
            {
                StaffForm staffForm = new StaffForm();
                staffForm.Show();
            }
            else
            {
                MessageBox.Show("User Not Found");
            }
        }

       
    }
}
