﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm.Forms
{
    public partial class DoctorForm : Form
    {
        public DoctorForm()
        {
            InitializeComponent();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void patientInfoBtn_Click(object sender, EventArgs e)
        {
            sidePanel.Height = patientInfoBtn.Height;
            sidePanel.Top = patientInfoBtn.Top;

            patientInfoControl1.Dock = DockStyle.Fill;
            patientInfoControl1.Visible = true;

            prescriptionControl1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sidePanel.Height = prescriptionBtn.Height;
            sidePanel.Top = prescriptionBtn.Top;

            prescriptionControl1.Dock = DockStyle.Fill;
            prescriptionControl1.Visible = true;

            patientInfoControl1.Visible = false;
        }

        private void messageBtn_Click(object sender, EventArgs e)
        {
            sidePanel.Height = messageBtn.Height;
            sidePanel.Top = messageBtn.Top;
        }
    }
}
